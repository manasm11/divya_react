import React from 'react'
import App from './App.client'
import ReactDOM from 'react-dom'


ReactDOM.render(<App/>, document.getElementById('root'))
