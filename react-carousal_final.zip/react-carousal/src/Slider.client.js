import React, { useRef } from "react";

export default function Slider({ slides }) {
  const isScrollRef = useRef()

  function getSwiper() {
    return document.getElementsByClassName("swiper")[0]
  }

  function getDelta() {
    const width = document.getElementsByClassName("swiper")[0].scrollWidth
    return width / slides.length
  }

  function handleScroll(e) {
    clearTimeout(isScrollRef.current);
    isScrollRef.current = setTimeout(function () {
      const currentTouch = e.target.scrollLeft
      const newCurrent = Math.round(currentTouch/getDelta())
      getSwiper().scrollTo({
        left: newCurrent * getDelta(),
        behavior: "smooth",
      })
    }, 66);
  }

  return (
    <div className='slider'>
      <div className='swiper' onScroll={handleScroll}>
        {slides.map((slide, index) =>
          <img key={index} className='sliderImage' src={slide.image} alt="" />)}
      </div>
    </div>
  );
};