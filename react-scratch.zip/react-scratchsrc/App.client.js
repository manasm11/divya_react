import React from 'react'
// import './styles.css'
import Slider from './Slider.client'

const ImageData = [
  {
    image:
      "https://upload.wikimedia.org/wikipedia/commons/thumb/0/08/Un1.svg/1920px-Un1.svg.png",
  },
  {
    image:
      "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3b/Deux.svg/240px-Deux.svg.png",
  },
  {
    image:
      "https://upload.wikimedia.org/wikipedia/commons/thumb/6/6d/Trois.svg/1920px-Trois.svg.png",
  },
  {
    image:
      "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e4/Quatre.svg/240px-Quatre.svg.png",
  },
];
export default function App() {
  return (
    <Slider slides={ImageData} />
  )
}